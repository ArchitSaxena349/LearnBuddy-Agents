import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './components/Home'

import Dashboard from './components/dashboard'
import CompanionChat from './components/companion-chat'
import Courses from './components/courses'
import './App.css'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
       
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/companion" element={<CompanionChat />} />
          <Route path="/courses" element={<Courses />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App
